import pickle

if __name__ == "__main__":
	l = [['val1','val2','compl'],['val1','val2','displ']]
	
	for i in l[0:1]:
		print i